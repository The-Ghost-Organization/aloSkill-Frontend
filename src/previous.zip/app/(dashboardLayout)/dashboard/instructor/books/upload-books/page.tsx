"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  AlertCircle,
  ArrowLeft,
  BookOpen,
  Building,
  Calendar,
  DollarSign,
  Eye,
  FileText,
  Hash,
  ImageIcon,
  Info,
  Languages,
  Loader,
  PenTool,
  Save,
  Star,
  Tag,
  Upload,
  User,
  X,
} from "lucide-react";
import dynamic from "next/dynamic";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import * as z from "zod";
import { apiClient } from "../../../../../../lib/api/client";
import { useSessionContext } from "../../../../../contexts/SessionContext";
import { type BookEditData } from "../books.types";

const PdfPreviewModal = dynamic(() => import("./PdfPreviewModal.tsx"), {
  ssr: false,
});

const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

function getInstructorName(user: unknown): string {
  if (!user || typeof user !== "object") return "";

  const profile = user as Record<string, unknown>;
  const directName = [profile["name"], profile["fullName"], profile["displayName"]].find(
    value => typeof value === "string" && value.trim().length > 0
  );

  if (typeof directName === "string") return directName.trim();

  const firstName = typeof profile["firstName"] === "string" ? profile["firstName"].trim() : "";
  const lastName = typeof profile["lastName"] === "string" ? profile["lastName"].trim() : "";

  return [firstName, lastName].filter(Boolean).join(" ");
}

function extractBunnyUrl(payload: unknown): string {
  const candidates: unknown[] = [payload];

  if (payload && typeof payload === "object") {
    const value = payload as Record<string, unknown>;
    candidates.push(value["url"], value["fileUrl"], value["location"], value["data"]);

    if (value["data"] && typeof value["data"] === "object") {
      const nested = value["data"] as Record<string, unknown>;
      candidates.push(nested["url"], nested["fileUrl"], nested["location"]);
    }
  }

  for (const candidate of candidates) {
    if (typeof candidate !== "string") continue;

    let normalized = candidate.trim().replace(/^["']|["']$/g, "");
    if (!normalized) continue;

    if (normalized.startsWith("//")) {
      normalized = `https:${normalized}`;
    } else if (/^[\w.-]+\.b-cdn\.net\//i.test(normalized)) {
      normalized = `https://${normalized}`;
    }

    try {
      const url = new URL(normalized);
      if (url.protocol === "https:") return url.href;
    } catch {
      // Try the next supported response shape.
    }
  }

  throw new Error("Bunny upload succeeded, but the server did not return a valid HTTPS CDN URL.");
}

const bookSchema = z
  .object({
    title: z
      .string()
      .min(1, "Book title is required")
      .regex(/^[^<>]*$/, "Title must not contain any opening or closing HTML tags"),
    author: z
      .string()
      .min(1, "Author name is required")
      .regex(/^[^<>]*$/, "Author name must not contain any opening or closing HTML tags"),
    translator: z
      .string()
      .regex(/^[^<>]*$/, "Translator name must not contain any opening or closing HTML tags")
      .optional(),
    editor: z
      .string()
      .regex(/^[^<>]*$/, "Editor name must not contain any opening or closing HTML tags")
      .optional(),
    publisher: z
      .string()
      .min(1, "Publisher is required")
      .regex(/^[^<>]*$/, "Publisher name must not contain any opening or closing HTML tags"),
    publishYear: z
      .string()
      .min(1, "Publish year is required")
      .regex(/^\d{4}$/, "Must be a valid 4-digit year (e.g., 2024)")
      .refine(val => {
        const year = parseInt(val, 10);
        const currentYear = new Date().getFullYear();
        return year >= 1000 && year <= currentYear + 1;
      }, "Year must be between 1000 and next year"),
    ratings: z
      .string()
      .min(1, "Ratings is required")
      .max(5, "Ratings cannot exceed 5")
      .regex(/^[^<>]*$/, "Ratings must not contain any opening or closing HTML tags"),
    description: z
      .string()
      .min(10, "Description must be at least 10 characters")
      .regex(/^[^<>]*$/, "Description must not contain any opening or closing HTML tags"),

    purchaseCost: z.coerce.number().min(0, "Purchase Cost cannot be negative").optional(),
    physicalRegularPrice: z.coerce
      .number()
      .min(0, "Physical Regular Price cannot be negative")
      .optional(),
    physicalSalePrice: z.coerce
      .number()
      .min(0, "Physical Sale Price cannot be negative")
      .optional(),
    digitalRegularPrice: z.coerce
      .number()
      .min(0, "Digital Regular Price cannot be negative")
      .optional(),
    digitalSalePrice: z.coerce.number().min(0, "Digital Sale Price cannot be negative").optional(),
    stock: z.coerce.number().int().min(0, "Stock cannot be negative").optional(),

    isbn: z
      .string()
      .regex(/^[^<>]*$/, "ISBN must not contain any opening or closing HTML tags")
      .optional(),
    edition: z
      .string()
      .regex(/^[^<>]*$/, "Edition must not contain any opening or closing HTML tags")
      .optional(),
    pages: z.coerce
      .number()
      .int()
      .positive("Pages must not contain any negative numbers")
      .min(1, "Pages is required"),
    weight: z.coerce.number().positive("Weight must not contain any negative numbers").optional(),
    language: z.string().min(1, "Language is required"),

    category: z.string().min(1, "Category is required"),
    formats: z.array(z.string()).min(1, "Select at least one format"),
    status: z.enum(["PENDING", "DRAFT"]).default("PENDING"),

    metaKeywords: z
      .string()
      .regex(/^[^<>]*$/, "Objectives must not contain any opening or closing HTML tags")
      .optional(),
    metaDescription: z
      .string()
      .regex(/^[^<>]*$/, "Meta description must not contain any opening or closing HTML tags")
      .optional(),
    coverImageUrl: z.url("Cover Image url must be a valid URL"),
    files: z.array(
      z.object({
        name: z
          .string()
          .regex(/^[^<>]*$/, "File names must not contain any opening or closing HTML tags"),
        url: z.url("File url must be a valid URL"),
        fileType: z.enum(["PREVIEW", "EBOOK"]),
      })
    ),
    coverImage: z.union([
      z.url("Cover image must be a valid URL"),
      z.custom<File>(v => v instanceof File, "Cover image must be a File"),
    ]),
    previewPdf: z.union([
      z.url("Preview PDF must be a valid URL"),
      z.custom<File>(v => v instanceof File, "Preview PDF must be a File"),
    ]),
    ebookPdf: z
      .union([
        z.url("E-Book PDF must be a valid URL"),
        z.custom<File>(v => v instanceof File, "E-Book PDF must be a File"),
      ])
      .optional(),
  })
  .refine(
    data => {
      if (data.formats.includes("E-Book") && !data.ebookPdf) {
        return false;
      }
      return true;
    },
    {
      message: "EbookPdf is required when E-Book format is selected",
      path: ["ebookPdf"],
    }
  )
  .refine(
    data => {
      if (data.formats.includes("Hardcover") && !data.physicalRegularPrice) {
        return false;
      }
      return true;
    },
    {
      message: "Physical Prices are required when Hardcover format is selected",
      path: ["physicalRegularPrice"],
    }
  )
  .refine(
    data => {
      if (data.formats.includes("E-Book") && !data.digitalRegularPrice) {
        return false;
      }
      return true;
    },
    {
      message: "Digital Prices are required when E-Book format is selected",
      path: ["digitalRegularPrice"],
    }
  )
  .refine(
    data => {
      if (data.physicalSalePrice && data.physicalRegularPrice) {
        if (data.physicalRegularPrice < data.physicalSalePrice) {
          return false;
        }
        return true;
      }
      return true;
    },
    {
      message: "HardCover Selling price cannot be higher than regular price",
      path: ["physicalSalePrice"],
    }
  )
  .refine(
    data => {
      if (data.formats.includes("E-Book")) {
        if (data.digitalSalePrice && data.digitalRegularPrice) {
          if (data.digitalRegularPrice < data.digitalSalePrice) {
            return false;
          }
          return true;
        }
      }
      return true;
    },
    {
      message: "Ebook Selling price cannot be higher than regular price",
      path: ["digitalSalePrice"],
    }
  );

type BookFormValues = z.input<typeof bookSchema>;

// ─── MAIN COMPONENT ────────────────────────────────────────────────
export default function AddBookPage() {
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [imageUploadError, setImageUploadError] = useState<string>("");
  const [fileUploadError, setFileUploadError] = useState<string>("");
  const [fileLoading, setFileLoading] = useState<boolean>(false);
  const [loadEditDataError, setLoadEditDataError] = useState<string>("");
  const [imageUploadLoading, setImageUploadLoading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string>("");
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [uploadedPdfPreview, setUploadedPdfPreview] = useState<string | null>(null);
  const [uploadedEbookPreview, setUploadedEbookPdf] = useState<string | null>(null);

  const { user } = useSessionContext();
  const instructorName = getInstructorName(user);
  const router = useRouter();
  const querydata = useSearchParams();
  const editBookId = querydata.get("editBookid");

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    trigger,
    control,
    formState: { errors, isSubmitting },
  } = useForm<BookFormValues>({
    resolver: zodResolver(bookSchema),
    defaultValues: {
      formats: ["Hardcover"],
      stock: 0,
      status: "PENDING",
    },
  });

  useEffect(() => {
    if (!instructorName) return;

    // Instructor uploads must always be authored by the logged-in instructor.
    setValue("author", instructorName, {
      shouldDirty: false,
      shouldValidate: true,
    });
  }, [instructorName, setValue]);

  useEffect(() => {
    const getCategories = async () => {
      const response = await apiClient.get<{ id: string; name: string }[]>("/book/categories");
      if (response.success && response.data) {
        setCategories(response.data);
      }
    };
    getCategories();
  }, []);

  useEffect(() => {
    if (!editBookId) return;
    try {
      const fetchBookData = async () => {
        const response = await apiClient.get<BookEditData>(
          `/book/instructor/books/edit?bookId=${editBookId}`
        );

        if (response.success && response.data) {
          const book = response.data;
          setValue("title", book.title);
          // Never restore a different author from book data on the instructor dashboard.
          // The logged-in instructor profile is the source of truth for authorship.
          if (instructorName) {
            setValue("author", instructorName, { shouldValidate: true });
          }
          setValue("translator", book.translator || "");
          setValue("editor", book.editor || "");
          setValue("publisher", book.publisher);
          setValue("publishYear", String(book.publishYear));
          setValue("ratings", String(book.ratings));
          setValue("description", book.description);
          setValue("purchaseCost", book.purchaseCost);
          setValue("physicalRegularPrice", book.physicalRegularPrice);
          setValue("physicalSalePrice", book.physicalSalePrice);
          setValue("digitalRegularPrice", book.digitalRegularPrice);
          setValue("digitalSalePrice", book.digitalSalePrice);
          setValue("stock", book.stock);
          setValue("isbn", book.isbn || "");
          setValue("edition", book.edition || "");
          setValue("pages", book.pages || undefined);
          setValue("weight", book.weight || undefined);
          setValue("language", book.language);
          setValue("category", book.category?.name || "");
          setValue(
            "formats",
            book.formats.map(f => (f === "HARDCOVER" ? "Hardcover" : "E-Book"))
          );
          setValue("metaKeywords", book.metaKeywords || "");
          setValue("metaDescription", book.metaDescription || "");
          setValue("status", book.status === "DRAFT" ? "DRAFT" : "PENDING");
          setValue("coverImageUrl", book.coverImage);
          setValue("coverImage", book.coverImage as unknown as File);
          setCoverPreview(book.coverImage);
          const files = book.files || [];
          setValue(
            "files",
            files.map(f => ({
              name: f.name,
              url: f.url,
              fileType: f.fileType as "PREVIEW" | "EBOOK",
            }))
          );
          const previewFile = files.find((f: any) => f.fileType === "PREVIEW");
          if (previewFile) {
            setValue("previewPdf", previewFile.url as unknown as File);
            setPdfPreviewUrl(encodeURI(previewFile.url));
            setUploadedPdfPreview(previewFile.name);
          }
          const ebookFile = files.find((f: any) => f.fileType === "EBOOK");
          if (ebookFile) {
            setValue("ebookPdf", ebookFile.url as unknown as File);
            setUploadedEbookPdf(ebookFile.name);
          }
        } else {
          setLoadEditDataError("Failed to load book data. Please try again.");
        }
      };
      fetchBookData();
    } catch (error) {
      setLoadEditDataError("Failed to load book data. Please try again.");
    }
  }, [editBookId, instructorName, setValue]);

  const selectedFormats = watch("formats");
  const isEbookSelected = selectedFormats.includes("E-Book");
  const isHardCoverSelected = selectedFormats.includes("Hardcover");
  const uploadedCover = watch("coverImage");
  const uploadedPreviewPdf = watch("previewPdf");
  const uploadedEbookPdf = watch("ebookPdf");

  // ─── HANDLERS ────────────────────────────────────────────────────

  const uploadFileToBunny = async (file: File): Promise<{ name: string; url: string }> => {
    setFileLoading(true);
    setFileUploadError("");

    if (!user?.email) {
      setFileUploadError("User not authenticated.");
      setFileLoading(false);
      return { name: "", url: "" };
    }

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await apiClient.postFormData<string>(
        "/course/instructor-file-upload?folder=books/pdfs",
        formData
      );

      if (!response.success || !response.data) {
        setFileUploadError(response.message || "Upload failed: try different Image or try again");
        return { name: "", url: "" };
      }

      return {
        name: file.name,
        url: extractBunnyUrl(response.data),
      };
    } catch (error: unknown) {
      setFileUploadError(error instanceof Error ? error.message : "An unknown error occurred.");
      return { name: "", url: "" };
    } finally {
      setFileLoading(false);
    }
  };

  const uploadImageToBunny = async (file: File): Promise<{ url: string }> => {
    setImageUploadLoading(true);
    setImageUploadError("");
    if (!user?.email) {
      setImageUploadError("User not authenticated.");
      setImageUploadLoading(false);
      return { url: "" };
    }

    try {
      setImageUploadError("");
      const formData = new FormData();
      formData.append("file", file);

      const response = await apiClient.postFormData<string>(
        "/course/instructor-file-upload?folder=books/covers",
        formData
      );

      if (!response.success || !response.data) {
        setImageUploadError("Upload failed: try different Image or try again");
        return { url: "" };
      }

      return {
        url: extractBunnyUrl(response.data),
      };
    } catch (error: unknown) {
      setImageUploadError(error instanceof Error ? error.message : "An unknown error occurred.");
      return { url: "" };
    } finally {
      setImageUploadLoading(false);
    }
  };

  // const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  //   const file = e.target.files?.[0];
  //   setImageError(null);

  //   if (file) {
  //     if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
  //       setImageError("Only .jpg, .jpeg, .png and .webp formats are supported.");
  //       return;
  //     }

  //     const img = document.createElement("img");
  //     const objectUrl = URL.createObjectURL(file);

  //     img.onload = async () => {
  //       if (img.width === 800 && img.height === 1200) {
  //         const uploadedImage = await uploadImageToBunny(file);
  //         if (uploadedImage.url !== "") {
  //           setValue("coverImageUrl", uploadedImage.url);
  //           setCoverPreview(objectUrl);
  //           setValue("coverImage", file);
  //           trigger("coverImage");
  //         }
  //       } else {
  //         setImageError(
  //           `Invalid dimensions. Got ${img.width}x${img.height}px. Required: 800x1200px.`
  //         );
  //         URL.revokeObjectURL(objectUrl);
  //       }
  //     };

  //     img.src = objectUrl;
  //   }
  // };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setImageError(null);

    if (file) {
      if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
        setImageError("Only .jpg, .jpeg, .png and .webp formats are supported.");
        return;
      }

      const img = document.createElement("img");
      const objectUrl = URL.createObjectURL(file);

      img.onload = async () => {
        // Enforce 130 x 186 px dimensions
        if (img.width === 130 && img.height === 186) {
          const uploadedImage = await uploadImageToBunny(file);
          if (uploadedImage.url !== "") {
            setValue("coverImageUrl", uploadedImage.url, {
              shouldDirty: true,
              shouldValidate: true,
            });
            setCoverPreview(objectUrl);
            setValue("coverImage", file);
            void trigger(["coverImage", "coverImageUrl"]);
          }
        } else {
          setImageError(
            `Invalid dimensions. Got ${img.width}x${img.height}px. Required: 130x186px.`
          );
          URL.revokeObjectURL(objectUrl);
        }
      };

      img.src = objectUrl;
    }
  };

  const handlePdfUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    field: "previewPdf" | "ebookPdf"
  ) => {
    const file = e.target.files?.[0];
    if (file && file.type === "application/pdf") {
      const uploadedResult = await uploadFileToBunny(file);
      if (uploadedResult && uploadedResult.url !== "") {
        const currentFileType = field === "previewPdf" ? "PREVIEW" : "EBOOK";

        const fileItem = {
          name: uploadedResult.name,
          url: uploadedResult.url,
          fileType: currentFileType,
        } as const;

        const currentFiles = watch("files") || [];

        const filteredFiles = currentFiles.filter(item => item.fileType !== currentFileType);

        setValue("files", [...filteredFiles, fileItem]);
        setValue(field, file);
        trigger(field);

        if (field === "previewPdf") {
          setPdfPreviewUrl(URL.createObjectURL(file));
        }
      }
    }
  };

  const removeFile = async (field: "coverImage" | "previewPdf" | "ebookPdf") => {
    // setValue(field, undefined as any);
    if (field === "coverImage") {
      const deletedResult = await apiClient.delete("/course/delete-file", {
        fileUrl: watch("coverImageUrl"),
      });
      if (deletedResult.success) {
        if (coverPreview) URL.revokeObjectURL(coverPreview);
        setValue("coverImage", undefined as any);
        setValue("coverImageUrl", undefined as any);
        setCoverPreview(null);
        setImageError(null);
        setImageUploadError("");
      }
      return;
    }

    const currentFileType = field === "previewPdf" ? "PREVIEW" : "EBOOK";
    const currentFiles = watch("files") || [];
    const filteredFiles = currentFiles.filter(item => item.fileType !== currentFileType);

    if (field === "previewPdf") {
      const deletedResult = await apiClient.delete("/course/delete-file", {
        fileUrl: currentFiles.find(f => f.fileType === "PREVIEW")?.url || "",
      });
      if (!deletedResult.success) {
        return;
      }
      setValue("files", [...filteredFiles]);
      setValue("previewPdf", undefined as any);
      if (pdfPreviewUrl) URL.revokeObjectURL(pdfPreviewUrl);
      setPdfPreviewUrl(null);
      setFileUploadError("");
    }

    if (field === "ebookPdf") {
      const deletedResult = await apiClient.delete("/course/delete-file", {
        fileUrl: currentFiles.find(f => f.fileType === "EBOOK")?.url || "",
      });
      if (!deletedResult.success) {
        return;
      }
      setValue("files", [...filteredFiles]);
      setValue("ebookPdf", undefined as any);
      setFileUploadError("");
    }
  };

  const handleEbookFormatChange = async (format: string[]) => {
    if (!format.includes("E-Book") && !watch("formats")?.includes("E-Book")) {
      const value = watch("files") || [];
      const ebookValue = value.find(b => b.fileType === "EBOOK")?.url;
      if (!ebookValue || ebookValue !== "") {
        await apiClient.delete("/course/delete-file", {
          fileUrl: ebookValue,
        });
      }
      setValue("ebookPdf", undefined as any);
      trigger("ebookPdf");
      const filteredFiles = value.filter(item => item.fileType !== "EBOOK");
      setValue("files", [...filteredFiles]);
    }
  };

  const onSubmit = async (data: BookFormValues) => {
    if (!instructorName) {
      setUploadError(
        "Instructor name could not be loaded from your profile. Please complete your instructor profile before uploading a book."
      );
      return;
    }

    const { ebookPdf, previewPdf, coverImage, ...restData } = data;
    const rest = {
      ...restData,
      // Do not trust a client-side field value for instructor authorship.
      author: instructorName,
    };
    if (editBookId) {
      const updateResult = await apiClient.put<{ id: string }>(
        `/book/update-book?bookId=${editBookId}`,
        rest
      );
      if (updateResult.success) {
        alert("Book updated and sent for admin review.");
        router.push("/dashboard/instructor/books");
      } else {
        setUploadError(updateResult.message || "Failed to update book. Please try again.");
      }
    } else {
      const uploadBookResult = await apiClient.post<{ id: string }>("/book/upload-book", rest);
      if (uploadBookResult.success) {
        alert(
          rest.status === "DRAFT" ? "Book draft saved." : "Book uploaded and sent for admin review."
        );
        router.push("/dashboard/instructor/books");
      } else {
        setUploadError(uploadBookResult.message || "Failed to upload book. Please try again.");
      }
    }
  };

  const submitWithStatus = (status: "PENDING" | "DRAFT") => {
    setValue("status", status);
    void handleSubmit(onSubmit)();
  };

  return (
    <div className='min-h-screen bg-[#F6F8FB] text-slate-900 font-sans'>
      {/* Sticky Top Bar */}
      <header className='sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-slate-200/80'>
        <div className='px-7 h-16 flex items-center justify-between'>
          <div className='flex items-center gap-3'>
            <Link
              href='/dashboard/instructor/books'
              className='p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-all'
            >
              <ArrowLeft size={20} />
            </Link>
            <div className='flex items-center gap-2 text-sm'>
              <span className='text-slate-400'>Books</span>
              <span className='text-slate-300'>/</span>
              <span className='text-slate-800 font-semibold'>
                {editBookId ? "Edit" : "Add New"}
              </span>
            </div>
          </div>

          {(uploadError || loadEditDataError) && (
            <div className='flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5'>
              <AlertCircle size={15} />
              <span>{uploadError || loadEditDataError}</span>
            </div>
          )}

          <div className='flex items-center gap-3'>
            {!editBookId ? (
              <>
                <button
                  type='button'
                  onClick={() => submitWithStatus("DRAFT")}
                  disabled={isSubmitting}
                  className='px-4 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 hover:text-slate-900 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer'
                >
                  Save Draft
                </button>
                <button
                  type='button'
                  onClick={() => submitWithStatus("PENDING")}
                  disabled={isSubmitting}
                  className='flex items-center gap-2 px-5 py-2 text-sm font-semibold rounded-lg bg-linear-to-r from-orange to-orange-dark text-white hover:from-orange-dark hover:to-orange shadow-sm shadow-orange/20 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer'
                >
                  {isSubmitting ? (
                    <span className='animate-pulse'>Processing...</span>
                  ) : (
                    <>
                      <Save size={15} />
                      Submit for Review
                    </>
                  )}
                </button>
              </>
            ) : (
              <button
                type='button'
                onClick={() => submitWithStatus("PENDING")}
                disabled={isSubmitting}
                className='flex items-center gap-2 px-5 py-2 text-sm font-semibold rounded-lg bg-linear-to-r from-orange to-orange-dark text-white hover:from-orange-dark hover:to-orange shadow-sm shadow-orange/20 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer'
              >
                {isSubmitting ? (
                  <span className='animate-pulse'>Updating...</span>
                ) : (
                  <>
                    <Save size={15} />
                    Update & Resubmit
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </header>

      <main className='p-7 animate-slide-up'>
        <div className='mb-7'>
          <div className='inline-flex items-center gap-1.5 text-xs font-semibold text-orange-dark bg-orange/10 border border-orange/20 rounded-full px-3 py-1 mb-3'>
            <BookOpen size={11} />
            {editBookId ? "Edit Entry" : "New Entry"}
          </div>
          <h1 className='text-3xl font-bold tracking-tight text-slate-950'>
            {editBookId ? "Edit Book" : "Add New Book"}
          </h1>
          <p className='text-slate-500 text-sm mt-1'>
            Your submission will be published only after an administrator approves it.
          </p>
        </div>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className='grid grid-cols-1 lg:grid-cols-3 gap-6'
        >
          {/* ── LEFT COLUMN ── */}
          <div className='lg:col-span-2 space-y-6'>
            {/* General Information */}
            <Card
              icon={
                <Info
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='General Information'
            >
              <div className='space-y-4'>
                <Field
                  label='Book Title *'
                  error={errors.title?.message}
                >
                  <input
                    {...register("title")}
                    type='text'
                    className={getInputClass(!!errors.title)}
                    placeholder='e.g. উদ্দেশ্যহীন আর কত দিন?'
                  />
                </Field>

                <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                  <Field
                    label='Main Author *'
                    error={errors.author?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("author")}
                        type='text'
                        readOnly
                        aria-readonly='true'
                        value={instructorName}
                        className={`${getInputClass(!!errors.author)} pl-10 cursor-not-allowed bg-slate-50 text-slate-600`}
                        placeholder='Instructor name from profile'
                      />
                      <User
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                    <p className='mt-1.5 text-xs leading-5 text-slate-400'>
                      Author is fixed to your instructor profile and cannot be changed here.
                    </p>
                  </Field>
                  <Field
                    label='Publisher *'
                    error={errors.publisher?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("publisher")}
                        type='text'
                        className={`${getInputClass(!!errors.publisher)} pl-10`}
                        placeholder='Publisher Name'
                      />
                      <Building
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                  </Field>
                </div>

                <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                  <Field
                    label='Translator'
                    error={errors.translator?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("translator")}
                        type='text'
                        className={`${getInputClass(!!errors.translator)} pl-10`}
                        placeholder='Translator Name (Optional)'
                      />
                      <Languages
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                  </Field>
                  <Field
                    label='Editor'
                    error={errors.editor?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("editor")}
                        type='text'
                        className={`${getInputClass(!!errors.editor)} pl-10`}
                        placeholder='Editor Name (Optional)'
                      />
                      <PenTool
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                  </Field>
                  <Field
                    label='Published Year *'
                    error={errors.publishYear?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("publishYear")}
                        type='number'
                        max={new Date().getFullYear() + 1}
                        placeholder='YYYY (e.g. 2024)'
                        className={`${getInputClass(!!errors.publishYear)} pl-10`}
                      />
                      <Calendar
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                  </Field>
                  <Field
                    label='Ratings (1-5) *'
                    error={errors.ratings?.message}
                  >
                    <div className='relative'>
                      <input
                        {...register("ratings")}
                        type='text'
                        className={`${getInputClass(!!errors.ratings)} pl-10`}
                        placeholder='Ratings (1-5)'
                      />
                      <Star
                        size={16}
                        className='absolute left-3.5 top-3.5 text-slate-400'
                      />
                    </div>
                  </Field>
                </div>

                <Field
                  label='Description *'
                  error={errors.description?.message}
                >
                  <textarea
                    {...register("description")}
                    rows={5}
                    className={`${getInputClass(!!errors.description)} resize-none`}
                    placeholder='Write the book summary here...'
                  />
                </Field>
              </div>
            </Card>

            {/* Pricing & Stock */}
            <Card
              icon={
                <DollarSign
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='Pricing & Stock'
            >
              {isHardCoverSelected && (
                <div className='mb-4'>
                  <Field
                    label='Book Purchase Cost (TK)'
                    error={errors.purchaseCost?.message}
                  >
                    <input
                      {...register("purchaseCost")}
                      type='number'
                      min={0}
                      className={`${getInputClass(!!errors.purchaseCost)}`}
                    />
                  </Field>
                </div>
              )}
              <div className='grid grid-cols-1 md:grid-cols-2 gap-4 mb-4'>
                {isHardCoverSelected && (
                  <>
                    <Field
                      label='HardCover Regular Price (TK) *'
                      error={errors.physicalRegularPrice?.message}
                    >
                      <input
                        {...register("physicalRegularPrice")}
                        type='number'
                        min={0}
                        className={`${getInputClass(!!errors.physicalRegularPrice)}`}
                      />
                    </Field>
                    <Field
                      label='HardCover Sale Price (TK) *'
                      error={errors.physicalSalePrice?.message}
                    >
                      <input
                        {...register("physicalSalePrice")}
                        type='number'
                        min={0}
                        className={getInputClass(!!errors.physicalSalePrice)}
                      />
                    </Field>
                  </>
                )}
                {isEbookSelected && (
                  <>
                    <Field
                      label='Ebook Regular Price (TK) *'
                      error={errors.digitalRegularPrice?.message}
                    >
                      <input
                        {...register("digitalRegularPrice")}
                        type='number'
                        min={0}
                        className={`${getInputClass(!!errors.digitalRegularPrice)}`}
                      />
                    </Field>
                    <Field
                      label='Ebook Sale Price (TK) *'
                      error={errors.digitalSalePrice?.message}
                    >
                      <input
                        {...register("digitalSalePrice")}
                        type='number'
                        min={0}
                        className={getInputClass(!!errors.digitalSalePrice)}
                      />
                    </Field>
                  </>
                )}
              </div>
              <Field
                label='Stock Quantity'
                error={errors.stock?.message}
              >
                <input
                  {...register("stock")}
                  type='number'
                  min={0}
                  className={getInputClass(!!errors.stock)}
                />
              </Field>
            </Card>

            {/* Specifications */}
            <Card
              icon={
                <Hash
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='Specifications'
            >
              <div className='grid grid-cols-1 md:grid-cols-2 gap-4 mb-4'>
                <Field
                  label='ISBN'
                  error={errors.isbn?.message}
                >
                  <input
                    {...register("isbn")}
                    type='text'
                    className={getInputClass(!!errors.isbn)}
                    placeholder='978-...'
                  />
                </Field>
                <Field
                  label='Edition'
                  error={errors.edition?.message}
                >
                  <input
                    {...register("edition")}
                    type='text'
                    className={getInputClass(!!errors.edition)}
                    placeholder='1st Edition'
                  />
                </Field>
                <Field
                  label='Pages *'
                  error={errors.pages?.message}
                >
                  <input
                    {...register("pages")}
                    type='number'
                    className={getInputClass(!!errors.pages)}
                    placeholder='Number of Pages'
                  />
                </Field>
                <Field
                  label='Language *'
                  error={errors.language?.message}
                >
                  <select
                    {...register("language")}
                    className={getInputClass(!!errors.language)}
                  >
                    <option value=''>Select Language</option>
                    <option value='Bengali'>Bengali</option>
                    <option value='English'>English</option>
                    <option value='Arabic'>Arabic</option>
                  </select>
                </Field>
              </div>
              <Field
                label='Book Weight (KG)'
                error={errors.weight?.message}
              >
                <input
                  {...register("weight")}
                  type='number'
                  className={getInputClass(!!errors.weight)}
                  placeholder='Book Weight (KG)'
                />
              </Field>
            </Card>

            {/* SEO Meta */}
            {/* <Card
              icon={
                <Search
                  size={15}
                  className='text-violet-400'
                />
              }
              iconBg='bg-violet-500/10'
              title='SEO Meta'
            >
              <div className='space-y-4'>
                <Field
                  label='Meta Keywords'
                  error={errors.metaKeywords?.message}
                >
                  <input
                    {...register("metaKeywords")}
                    type='text'
                    className={getInputClass(!!errors.metaKeywords)}
                    placeholder='Islamic, Spirituality...'
                  />
                </Field>
                <Field
                  label='Meta Description'
                  error={errors.metaDescription?.message}
                >
                  <textarea
                    {...register("metaDescription")}
                    rows={3}
                    className={`${getInputClass(!!errors.metaDescription)} resize-none`}
                    placeholder='Short SEO summary...'
                  />
                </Field>
              </div>
            </Card> */}
          </div>

          {/* ── RIGHT COLUMN ── */}
          <div className='space-y-6'>
            {/* Book Cover */}
            <Card
              icon={
                <ImageIcon
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='Book Cover'
            >
              <Field
                label=''
                error={
                  (errors.coverImage?.message as string) ||
                  imageError ||
                  imageUploadError ||
                  undefined
                }
              >
                {imageUploadLoading ? (
                  <div className='p-6 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 flex items-center justify-center gap-2'>
                    <Loader className='animate-spin' /> Uploading...
                  </div>
                ) : (
                  <>
                    {uploadedCover || coverPreview ? (
                      <div className='relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50 group'>
                        <Image
                          width={130}
                          height={186}
                          priority
                          src={coverPreview as string}
                          alt='Cover Image Preview'
                          className='w-full h-auto object-cover'
                        />
                        <button
                          type='button'
                          onClick={() => removeFile("coverImage")}
                          className='absolute top-2 right-2 p-2 bg-red-500/90 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-all cursor-pointer'
                        >
                          <X size={16} />
                        </button>
                        <div className='absolute bottom-2 left-2 px-2 py-1 bg-slate-950/70 backdrop-blur rounded-md text-[10px] text-white'>
                          130 × 186px
                        </div>
                      </div>
                    ) : (
                      <div className='relative'>
                        <input
                          type='file'
                          accept='.jpg,.jpeg,.png,.webp'
                          className='absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10'
                          onChange={handleImageUpload}
                        />
                        <div
                          className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center transition-all ${imageError || imageUploadError || errors.coverImage ? "border-red-300 bg-red-50" : "border-slate-200 hover:border-orange/40 hover:bg-orange/5"}`}
                        >
                          <div className='w-11 h-11 rounded-xl bg-orange/10 border border-orange/15 flex items-center justify-center mb-3'>
                            <Upload
                              size={18}
                              className='text-slate-400'
                            />
                          </div>
                          <p className='text-sm font-semibold text-slate-600 text-center'>
                            Upload Cover
                          </p>
                          <span className='text-xs text-slate-400 mt-1'>Required: 130 × 186px</span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </Field>
            </Card>

            {/* Preview PDF */}
            <Card
              icon={
                <Eye
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='Preview PDF (Read Only)'
            >
              <Field
                label='For User Preview'
                error={(errors.previewPdf?.message as string) || fileUploadError}
              >
                {fileLoading ? (
                  <div className='p-6 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 flex items-center justify-center gap-2'>
                    <Loader className='animate-spin' /> Uploading file...
                  </div>
                ) : (
                  <>
                    {uploadedPreviewPdf ? (
                      <FilePreviewItem
                        file={uploadedPreviewPdf as File}
                        fileName={uploadedPdfPreview as string}
                        onRemove={() => removeFile("previewPdf")}
                        onPreview={() => setIsPdfModalOpen(true)}
                      />
                    ) : (
                      <div className='relative'>
                        <input
                          type='file'
                          accept='.pdf'
                          className='absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10'
                          onChange={e => handlePdfUpload(e, "previewPdf")}
                        />
                        <div className='border-2 border-dashed border-slate-200 rounded-xl p-6 flex flex-col items-center justify-center bg-slate-50/70 hover:border-orange/40 hover:bg-orange/5 transition-all'>
                          <Upload
                            size={18}
                            className='text-slate-400 mb-2'
                          />
                          <span className='text-xs text-slate-500'>Upload PDF for Preview</span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </Field>
            </Card>

            {/* Category & Format */}
            <Card
              icon={
                <Tag
                  size={15}
                  className='text-orange-dark'
                />
              }
              iconBg='bg-orange/10'
              title='Category & Format'
            >
              <div className='space-y-5'>
                <Field
                  label='Category *'
                  error={errors.category?.message}
                >
                  <select
                    {...register("category")}
                    className={getInputClass(!!errors.category)}
                  >
                    <option value=''>Select Category</option>
                    {categories &&
                      categories.map((cat: any) => (
                        <option
                          key={cat.id}
                          value={cat.name}
                        >
                          {cat.name}
                        </option>
                      ))}
                  </select>
                </Field>

                <Field
                  label='Format *'
                  error={errors.formats?.message}
                >
                  <div className='grid grid-cols-2 gap-3 mt-1'>
                    <Controller
                      name='formats'
                      control={control}
                      render={({ field }) => (
                        <>
                          {["Hardcover", "E-Book"].map(fmt => (
                            <label
                              key={fmt}
                              className={`flex items-center gap-3 border rounded px-4 py-3 cursor-pointer transition-colors duration-300 ${field.value.includes(fmt) ? "bg-orange text-white border-orange" : "bg-white border-slate-200 hover:border-slate-300"}`}
                            >
                              <input
                                type='checkbox'
                                value={fmt}
                                checked={field.value.includes(fmt)}
                                onChange={e => {
                                  const checked = e.target.checked;
                                  const newValue = checked
                                    ? [...field.value, fmt]
                                    : field.value.filter(v => v !== fmt);
                                  field.onChange(newValue);
                                  handleEbookFormatChange(newValue);
                                }}
                                className='w-4 h-4 accent-orange-dark'
                              />
                              <span className='text-sm'>{fmt}</span>
                            </label>
                          ))}
                        </>
                      )}
                    />
                  </div>
                </Field>
              </div>
            </Card>

            {/* Conditional E-Book Upload */}
            {isEbookSelected && (
              <div className='animate-slide-up'>
                <Card
                  icon={
                    <FileText
                      size={15}
                      className='text-orange-dark'
                    />
                  }
                  iconBg='bg-orange/10'
                  title='Full E-Book File'
                >
                  <Field
                    label='Product File'
                    error={errors.ebookPdf?.message as string}
                  >
                    {fileLoading ? (
                      <div className='p-6 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 flex items-center justify-center gap-2'>
                        <Loader className='animate-spin' /> Uploading file...
                      </div>
                    ) : (
                      <>
                        {uploadedEbookPdf ? (
                          <FilePreviewItem
                            file={uploadedEbookPdf as File}
                            fileName={uploadedEbookPreview as string}
                            onRemove={() => removeFile("ebookPdf")}
                          />
                        ) : (
                          <div className='relative'>
                            <input
                              type='file'
                              accept='.pdf'
                              className='absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10'
                              onChange={e => handlePdfUpload(e, "ebookPdf")}
                            />
                            <div className='border-2 border-dashed border-slate-200 rounded-xl p-6 flex flex-col items-center justify-center bg-slate-50/70 hover:border-orange/40 hover:bg-orange/5 transition-all'>
                              <Upload
                                size={18}
                                className='text-slate-400 mb-2'
                              />
                              <span className='text-xs text-slate-500'>Upload Full Book PDF</span>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </Field>
                </Card>
              </div>
            )}
          </div>
        </form>
      </main>

      {/* ── PDF READER MODAL (Using react-pdf) ── */}
      {isPdfModalOpen && pdfPreviewUrl && (
        <PdfPreviewModal
          url={pdfPreviewUrl}
          fileName={uploadedPreviewPdf instanceof File ? uploadedPreviewPdf.name : "Preview"}
          onClose={() => setIsPdfModalOpen(false)}
        />
      )}
    </div>
  );
}

// ─── HELPER COMPONENTS ─────────────────────────────────────────────

// 2. File Item UI
function FilePreviewItem({
  file,
  fileName,
  onRemove,
  onPreview,
}: {
  file: File;
  fileName?: string;
  onRemove: () => void;
  onPreview?: () => void;
}) {
  return (
    <div className='flex items-center gap-3 bg-slate-50/80 border border-slate-200 rounded-xl p-3 group'>
      <div className='w-10 h-10 bg-orange/10 border border-orange/15 rounded-lg flex items-center justify-center shrink-0'>
        <FileText
          size={17}
          className='text-orange-dark'
        />
      </div>
      <div className='flex-1 min-w-0'>
        <p className='text-sm font-semibold truncate text-slate-700'>{file.name || fileName}</p>
        <p className='text-[10px] text-slate-400'>{(file.size / 1024 / 1024).toFixed(2)} MB</p>
      </div>
      <div className='flex items-center gap-1'>
        {onPreview && (
          <button
            type='button'
            onClick={onPreview}
            className='p-1.5 rounded-lg bg-orange/10 hover:bg-orange/15 text-orange-dark transition-colors'
            title='Preview PDF'
          >
            <Eye size={14} />
          </button>
        )}
        <button
          type='button'
          onClick={onRemove}
          className='p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-500 transition-colors'
          title='Remove'
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}

// 3. UI Helpers
function Field({
  label,
  children,
  error,
}: {
  label: string;
  children: React.ReactNode;
  error?: string;
}) {
  return (
    <div className='space-y-2'>
      <div className='flex justify-between items-center'>
        <label className='block text-[11px] font-semibold uppercase tracking-widest text-slate-500'>
          {label}
        </label>
        {error && (
          <span className='flex items-center gap-1 text-[10px] text-red-500 font-medium'>
            <AlertCircle size={10} /> {error}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}

function Card({
  icon,
  iconBg,
  title,
  children,
}: {
  icon: React.ReactNode;
  iconBg: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className='bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm shadow-slate-200/40'>
      <div className='flex items-center gap-3 px-6 py-4 border-b border-slate-100 bg-slate-50/50'>
        <div className={`p-2 rounded ${iconBg}`}>{icon}</div>
        <h2 className='text-sm font-semibold text-slate-800'>{title}</h2>
      </div>
      <div className='p-6'>{children}</div>
    </div>
  );
}

const getInputClass = (hasError: boolean) =>
  `w-full bg-white border rounded-xl px-4 py-3 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none [&>option]:bg-white [&>option]:text-slate-800 [&::-webkit-inner-spin-button]:appearance-none transition-all ${
    hasError
      ? "border-red-300 bg-red-50/30 focus:border-red-400 focus:ring-2 focus:ring-red-100"
      : "border-slate-200 hover:border-slate-300 focus:border-orange focus:ring-2 focus:ring-orange/10"
  }`;
